﻿using System;

namespace Practice2
{
    class Program
    {
        static void Main()
        {
            Console.Write("Километры: ");
            string km = Console.ReadLine();
            double KM = double.Parse(km);

            Console.WriteLine("Мили: {0:0.##}", KM / 1.609);
            Console.ReadKey();
        }
    }
}
